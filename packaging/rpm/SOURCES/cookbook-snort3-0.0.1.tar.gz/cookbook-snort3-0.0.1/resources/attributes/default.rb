# Flags
default['snort']['registered'] = false
default[:redborder][:snortd][:service] = 'snortd'
