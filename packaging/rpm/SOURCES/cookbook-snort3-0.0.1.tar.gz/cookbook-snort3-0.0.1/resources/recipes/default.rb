# Cookbook:: snort
# Recipe:: default
# Copyright:: 2024, redborder
# License:: Affero General Public License, Version 3

snort3_config 'config' do
  action :add
end
